﻿using System;

namespace Reminder.Storage.SqlServer.ADO.TestApp
{
	class Program
	{
		static void Main(string[] args)
		{
			var storage = new SqlReminderStorage(
				@"Data Source=localhost\SQLEXPRESS;Initial Catalog=Reminder;Integrated Security=true;");

			Guid id = storage.Add(
				DateTimeOffset.Now.AddMinutes(1),
				"Test message",
				"012345",
				Core.ReminderItemStatus.Failed);

			Console.WriteLine(id);
		}
	}
}
