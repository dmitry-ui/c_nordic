﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Reminder.Storage.Core;

namespace Reminder.Storage.SqlServer.ADO
{
	public class SqlReminderStorage : IReminderStorage
	{
		private string _connectionString;

		public SqlReminderStorage(string connectionString)
		{
			_connectionString = connectionString;
		}

		public Guid Add(DateTimeOffset date, string message, string contactId, ReminderItemStatus status)
		{
			using (var sqlConnection = new SqlConnection(_connectionString))
			{
				sqlConnection.Open();

				var cmd = sqlConnection.CreateCommand();
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "dbo.AddReminderItem";

				cmd.Parameters.AddWithValue("@contactId", contactId);
				cmd.Parameters.AddWithValue("@targetDate", date);
				cmd.Parameters.AddWithValue("@message", message);
				cmd.Parameters.AddWithValue("@statusId", (byte)status);

				return (Guid)cmd.ExecuteScalar();
			}

		}

		public ReminderItem Get(Guid id)
		{
			throw new NotImplementedException();
		}

		public List<ReminderItem> Get(ReminderItemStatus status)
		{
			throw new NotImplementedException();
		}

		public void Update(Guid id, ReminderItemStatus status)
		{
			throw new NotImplementedException();
		}
	}
}
