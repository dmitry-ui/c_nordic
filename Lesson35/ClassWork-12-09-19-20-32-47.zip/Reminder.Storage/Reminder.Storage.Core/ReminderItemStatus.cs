﻿namespace Reminder.Storage.Core
{
	public enum ReminderItemStatus
	{
		Awaiting,
		Ready,
		Sent,
		Failed
	}
}
