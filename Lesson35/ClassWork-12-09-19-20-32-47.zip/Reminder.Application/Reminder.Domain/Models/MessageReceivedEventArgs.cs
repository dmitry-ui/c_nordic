﻿namespace Reminder.Domain.Models
{
	public class MessageReceivedEventArgs: Receiver.Core.MessageReceivedEventArgs
	{
	}
}
